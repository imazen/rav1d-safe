from pathlib import Path
import subprocess,json,os
w=Path('/home/lilith/tmp/rav1d-wrapper-context-2026-09-07');records=[]
jobs=[('contracts-final-x86',['python3','tools/check-wrapper-contexts.py','--work-dir',str(w/'contracts-final'),'--target','x86_64-unknown-linux-gnu']),('contracts-final-arm',['python3','tools/check-wrapper-contexts.py','--work-dir',str(w/'contracts-final'),'--target','aarch64-unknown-linux-gnu']),('clippy-final-checked',['cargo','clippy','--no-default-features','--features','bitdepth_8,bitdepth_16','--','-D','warnings']),('clippy-final-cffi',['cargo','clippy','--no-default-features','--features','bitdepth_8,bitdepth_16,c-ffi','--','-D','warnings']),('unchecked-confirm',json.loads((w/'confirm-command.json').read_text()))]
for name,cmd in jobs:
 print('START',name,flush=True)
 with (w/(name+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=os.environ|{'CARGO_TERM_COLOR':'never'})
 records.append({'name':name,'command':cmd,'exit':r.returncode});(w/'followup.json').write_text(json.dumps(records,indent=2)+'\n')
 print('END',name,r.returncode,flush=True)
 assert r.returncode==0
