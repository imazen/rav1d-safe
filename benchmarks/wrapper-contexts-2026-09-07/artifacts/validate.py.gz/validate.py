import subprocess,json,os
from pathlib import Path
w=Path('/home/lilith/tmp/rav1d-wrapper-context-2026-09-07')
jobs=[
 ('contracts-x86',['python3','tools/check-wrapper-contexts.py','--work-dir',str(w/'contracts'),'--target','x86_64-unknown-linux-gnu']),
 ('contracts-arm',['python3','tools/check-wrapper-contexts.py','--work-dir',str(w/'contracts'),'--target','aarch64-unknown-linux-gnu']),
 ('lib-checked',['cargo','nextest','run','--release','--lib']),
 ('lib-unchecked',['cargo','nextest','run','--release','--features','unchecked','--lib']),
 ('lib-asm',['cargo','nextest','run','--release','--features','asm','--lib']),
 ('debug-vectors',['cargo','nextest','run','--test','decode_md5_committed','--test','safe_simd_crashes','--test','fuzz_regression']),
 ('clippy-checked',['cargo','clippy','--no-default-features','--features','bitdepth_8,bitdepth_16','--','-D','warnings']),
 ('clippy-cffi',['cargo','clippy','--no-default-features','--features','bitdepth_8,bitdepth_16,c-ffi','--','-D','warnings']),
 ('arm-check',['cargo','check','--target','aarch64-unknown-linux-gnu']),
 ('conformance-1',['cargo','nextest','run','--release','--test','decode_md5_verify']),
 ('conformance-8',['cargo','nextest','run','--release','--test','decode_md5_verify']),
 ('final-consumers',['python3','benchmarks/tracker-sharding-2026-09-07/build.py','--repo','/home/lilith/work/zen/rav1d-safe','--work-dir',str(w),'--label','final','--modes','checked','unchecked','asm','--refresh-lock']),
]
records=[]
for name,cmd in jobs:
 env=os.environ.copy();env['CARGO_TERM_COLOR']='never'
 if name=='conformance-8':env['RAV1D_MD5_THREADS']='8'
 print('START',name,flush=True)
 with (w/(name+'.log')).open('w') as log:
  result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
 records.append(dict(name=name,command=cmd,exit=result.returncode,threads=env.get('RAV1D_MD5_THREADS','1')))
 (w/'validation.json').write_text(json.dumps(records,indent=2)+'\n')
 print('END',name,result.returncode,flush=True)
assert all(r['exit']==0 for r in records),records
