	.file	"cdf_auto_codegen.62d3ea20812b740a-cgu.0"
	.section	.text._RNvCs8u3B0jmqZe0_16cdf_auto_codegen16cdf_array_signed,"ax",@progbits
	.globl	_RNvCs8u3B0jmqZe0_16cdf_auto_codegen16cdf_array_signed
	.p2align	4
	.type	_RNvCs8u3B0jmqZe0_16cdf_auto_codegen16cdf_array_signed,@function
_RNvCs8u3B0jmqZe0_16cdf_auto_codegen16cdf_array_signed:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %rbp, -16
	movl	%ecx, %eax
	movl	%edx, %ecx
	movq	(%rdi), %rdx
	movzwl	%dx, %ebp
	movl	%edx, %r8d
	shrl	$16, %r8d
	movq	%rdx, %r9
	shrq	$32, %r9
	movl	$-32768, %r10d
	subl	%edx, %r10d
	movzwl	%r10w, %ebx
	andb	$15, %cl
	shrl	%cl, %ebx
	shrl	%cl, %ebp
	xorl	%r10d, %r10d
	testq	%rsi, %rsi
	cmovel	%r10d, %ebx
	movzwl	%r9w, %r11d
	cmovnel	%r10d, %ebp
	subl	%ebp, %edx
	movl	$-32768, %ebp
	subl	%r8d, %ebp
	movzwl	%bp, %ebp
	shrl	%cl, %ebp
	movl	%r8d, %r14d
	shrl	%cl, %r14d
	addl	%ebx, %edx
	cmpq	$2, %rsi
	cmovbl	%r10d, %ebp
	movl	$-32768, %ebx
	cmovael	%r10d, %r14d
	subl	%r14d, %r8d
	addl	%ebp, %r8d
	subl	%r9d, %ebx
	movzwl	%bx, %ebx
	shrl	%cl, %ebx
	shrl	%cl, %r11d
	cmpq	$3, %rsi
	cmovbl	%r10d, %ebx
	cmovael	%r10d, %r11d
	subl	%r11d, %r9d
	addl	%ebx, %r9d
	cmpw	$32, %ax
	adcw	$0, %ax
	movzwl	%ax, %eax
	shlq	$48, %rax
	movzwl	%r9w, %ecx
	shlq	$32, %rcx
	orq	%rax, %rcx
	shll	$16, %r8d
	orq	%rcx, %r8
	movzwl	%dx, %eax
	orq	%r8, %rax
	movq	%rax, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	_RNvCs8u3B0jmqZe0_16cdf_auto_codegen16cdf_array_signed, .Lfunc_end0-_RNvCs8u3B0jmqZe0_16cdf_auto_codegen16cdf_array_signed
	.cfi_endproc

	.section	.text._RNvCs8u3B0jmqZe0_16cdf_auto_codegen9cdf_array,"ax",@progbits
	.globl	_RNvCs8u3B0jmqZe0_16cdf_auto_codegen9cdf_array
	.p2align	4
	.type	_RNvCs8u3B0jmqZe0_16cdf_auto_codegen9cdf_array,@function
_RNvCs8u3B0jmqZe0_16cdf_auto_codegen9cdf_array:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	%ecx, -4(%rsp)
	movl	%edx, %ecx
	movq	(%rdi), %rdx
	movzwl	%dx, %r11d
	movl	%edx, %r8d
	shrl	$16, %r8d
	movq	%rdx, %r9
	movl	$-32768, %r10d
	subl	%edx, %r10d
	movzwl	%r10w, %ebx
	andb	$15, %cl
	shrl	%cl, %ebx
	shrq	$32, %r9
	movl	$-32768, %r10d
	subl	%r8d, %r10d
	movzwl	%r10w, %r15d
	shrl	%cl, %r15d
	movq	%rdx, %r10
	movl	$-32768, %ebp
	subl	%r9d, %ebp
	movzwl	%bp, %ebp
	shrl	%cl, %ebp
	shrq	$48, %r10
	movl	$-32768, %r14d
	subl	%r10d, %r14d
	movzwl	%r14w, %r14d
	shrl	%cl, %r14d
	shrl	%cl, %r11d
	movzwl	%r9w, %r12d
	movl	%r8d, %eax
	shrl	%cl, %eax
	shrl	%cl, %r12d
	movl	%r10d, %r13d
	shrl	%cl, %r13d
	xorl	%ecx, %ecx
	testq	%rsi, %rsi
	cmovel	%ecx, %ebx
	cmovnel	%ecx, %r11d
	subl	%r11d, %edx
	addl	%ebx, %edx
	cmpq	$2, %rsi
	cmovbl	%ecx, %r15d
	cmovael	%ecx, %eax
	subl	%eax, %r8d
	addl	%r15d, %r8d
	cmpq	$3, %rsi
	cmovbl	%ecx, %ebp
	cmovael	%ecx, %r12d
	subl	%r12d, %r9d
	addl	%ebp, %r9d
	cmpq	$4, %rsi
	cmovbl	%ecx, %r14d
	cmovael	%ecx, %r13d
	subl	%r13d, %r10d
	addl	%r14d, %r10d
	shlq	$48, %r10
	movzwl	%r9w, %eax
	shlq	$32, %rax
	orq	%r10, %rax
	shll	$16, %r8d
	orq	%rax, %r8
	movzwl	%dx, %eax
	orq	%r8, %rax
	movq	%rax, (%rdi)
	movl	-4(%rsp), %eax
	cmpw	$32, %ax
	adcw	$0, %ax
	movw	%ax, 6(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	_RNvCs8u3B0jmqZe0_16cdf_auto_codegen9cdf_array, .Lfunc_end1-_RNvCs8u3B0jmqZe0_16cdf_auto_codegen9cdf_array
	.cfi_endproc

	.globl	_RNvCs8u3B0jmqZe0_16cdf_auto_codegen18cdf_array_separate
	.type	_RNvCs8u3B0jmqZe0_16cdf_auto_codegen18cdf_array_separate,@function
_RNvCs8u3B0jmqZe0_16cdf_auto_codegen18cdf_array_separate = _RNvCs8u3B0jmqZe0_16cdf_auto_codegen16cdf_array_signed
	.ident	"rustc version 1.98.1 (48a229cea 2026-09-01)"
	.section	".note.GNU-stack","",@progbits
