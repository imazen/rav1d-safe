#![forbid(unsafe_code)]
#![crate_type = "lib"]

#[inline(never)]
pub fn cdf_array(cdf: &mut [u16; 4], val: usize, rate: u16, count: u16) {
    let old = *cdf;
    let up = old.map(|p| (32768u16.wrapping_sub(p)) >> rate);
    let down = old.map(|p| p >> rate);
    let below: [u16; 4] = core::array::from_fn(|i| u16::from(i < val).wrapping_neg());
    *cdf = core::array::from_fn(|i| old[i].wrapping_add(up[i] & below[i]).wrapping_sub(down[i] & !below[i]));
    cdf[3] = count + u16::from(count < 32);
}

#[inline(never)]
pub fn cdf_array_separate(cdf: &mut [u16; 4], val: usize, rate: u16, count: u16) {
    let old = *cdf;
    let mut out = [0; 4];
    for i in 0..4 {
        let mask = u16::from(i < val).wrapping_neg();
        out[i] = old[i].wrapping_add((32768u16.wrapping_sub(old[i]) >> rate) & mask)
            .wrapping_sub((old[i] >> rate) & !mask);
    }
    out[3] = count + u16::from(count < 32);
    *cdf = out;
}

#[inline(never)]
pub fn cdf_array_signed(cdf: &mut [u16; 4], val: usize, rate: u16, count: u16) {
    let v = val.min(3) as i16;
    let old = *cdf;
    let mut out = [0; 4];
    for i in 0..4 {
        let mask = u16::from((i as i16) < v).wrapping_neg();
        out[i] = old[i].wrapping_add((32768u16.wrapping_sub(old[i]) >> rate) & mask)
            .wrapping_sub((old[i] >> rate) & !mask);
    }
    out[3] = count + u16::from(count < 32);
    *cdf = out;
}
